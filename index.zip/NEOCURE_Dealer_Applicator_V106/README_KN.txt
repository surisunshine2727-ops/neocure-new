NEOCURE Dealer / Applicator V106 OTP-first follow-up fix

- Forgot MPIN attempts SMS OTP first.
- Clears any old Admin-pending message before starting the OTP flow, so an old status does not remain visible.
- OTP failure/cancel path retains the Admin Help fallback in the existing code.
- Existing Firebase data and Pending requests are not modified.
- Admin UI/backend functions are not changed.
- Local static syntax check only; live SMS OTP has not been verified in this package.
- Deploy the dealer_applicator.html file to the same Vercel project currently serving neocure-new.vercel.app.
